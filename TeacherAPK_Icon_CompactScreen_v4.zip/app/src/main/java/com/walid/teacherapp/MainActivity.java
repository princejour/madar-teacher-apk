package com.walid.teacherapp;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(226, 232, 240));
        root.setPadding(dp(6), dp(6), dp(6), dp(8));
        setContentView(root);

        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setBackgroundColor(Color.rgb(15, 118, 110));
        topBar.setPadding(dp(8), dp(4), dp(8), dp(4));
        root.addView(topBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(46)
        ));

        Button backButton = new Button(this);
        backButton.setText("رجوع");
        backButton.setTextSize(14);
        backButton.setAllCaps(false);
        backButton.setTextColor(Color.rgb(15, 23, 42));
        backButton.setOnClickListener(v -> goBackOrExit());
        topBar.addView(backButton, new LinearLayout.LayoutParams(dp(88), ViewGroup.LayoutParams.MATCH_PARENT));

        TextView title = new TextView(this);
        title.setText("تطبيق الأستاذ");
        title.setTextColor(Color.WHITE);
        title.setTextSize(16);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        topBar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1));

        FrameLayout webContainer = new FrameLayout(this);
        webContainer.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams containerParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1
        );
        containerParams.setMargins(dp(0), dp(7), dp(0), dp(0));
        root.addView(webContainer, containerParams);

        webView = new WebView(this);
        webView.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        webView.setInitialScale(88);
        webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        webContainer.addView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setTextZoom(85);
        webView.setInitialScale(82);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setTextZoom(88);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(new WebViewClient(){
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.evaluateJavascript("(function(){if(document.getElementById('teacherCompactInjected'))return;var s=document.createElement('style');s.id='teacherCompactInjected';s.innerHTML='html,body{max-width:100%!important;overflow-x:hidden!important;-webkit-text-size-adjust:90%!important;text-size-adjust:90%!important}body{font-size:13px!important}.wrap{max-width:430px!important;width:100%!important;margin:0 auto!important;padding:6px!important}.card{padding:8px!important;margin:7px 0!important;border-radius:12px!important}input,select,textarea{font-size:13px!important;min-height:34px!important;padding:7px!important}button,.btn{font-size:13px!important;min-height:36px!important;padding:7px!important}table{width:100%!important;min-width:0!important;table-layout:fixed!important}th,td{font-size:10.5px!important;padding:5px 3px!important;word-break:break-word!important;white-space:normal!important}.tablebox{max-width:100%!important;overflow-x:auto!important}';document.head.appendChild(s);})();", null);
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void goBackOrExit() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            finish();
        }
    }

    @Override
    public void onBackPressed() {
        goBackOrExit();
    }
}
